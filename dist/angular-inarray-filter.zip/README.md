Angular InArray Filter
======================

Filter results that are contained inside an array

Documentation
-------------

Check the documentation of this repository at it's [GitHub Page](http://alejandrocarrasco.github.io/angular-inarray-filter/ "angular-inarray-filter by Alejandro Carrasco")

License
-------

Copyright 2014 Alejandro Carrasco.

Released under MIT License.
